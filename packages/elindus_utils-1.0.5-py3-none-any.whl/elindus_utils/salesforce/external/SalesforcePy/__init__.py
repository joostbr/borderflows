from __future__ import absolute_import
from . import sfdc

name = 'SalesforcePy'
client = sfdc.client

LoginException = sfdc.LoginException
