import csv
import io
import json
import logging
import time
import urllib.parse
from urllib.parse import quote_plus

import pandas as pd
import requests
from pandas import DataFrame

from elindus_utils.salesforce.external.SalesforcePy import sfdc
from elindus_utils.utils.utilspy import get_today_as_string, chunker
from elindus_utils.utils.utilspy import validate_required_attribute


class SalesforceClient():
    bearer_token = None
    version = 'v54.0'
    query_job_url = f'/services/data/{version}/jobs/query'

    def __init__(self, base_url: str = None,
                 password: str = None,
                 client_id: str = None,
                 client_secret: str = None,
                 username: str = None,
                 logger: logging.Logger = None):
        super().__init__()
        self.logger = logger if logger is not None else logging.getLogger(type(self).__name__)
        self.base_url = validate_required_attribute(base_url, 'base_url')
        self.password = validate_required_attribute(password, 'password')
        self.client_id = validate_required_attribute(client_id, 'client_id')
        self.client_secret = validate_required_attribute(client_secret, 'client_secret')
        self.username = validate_required_attribute(username, 'username')
        self.username_encoded = urllib.parse.quote_plus(validate_required_attribute(username, 'username'))
        self.auth_url = '/services/oauth2/token'
        self.bearer_token = self.__get_token()
        self.salesforcepy = self.__get_salesforce_client()

    def query_sf_data(self, object_name: str, query_fields: list, append_query: str = '') -> DataFrame:
        """
        Handles Salesforce  SELECT Query jobs
        :param object_name: Salesforce object api name
        :param query_fields: Salesforce object column names
        :param append_query: Where Clause
        :return: pandas.DataFrame
        e.g.:
        query_sf_data('Agreement__c', ['Id', 'Name'], 'where Settlement_paid_on__c = NULL')
        """
        query = f"""SELECT {', '.join(f"{field}" for field in query_fields)} FROM {object_name} {append_query}"""
        body = json.dumps({
            "operation": "query",
            "query": query
        })
        result, job_id = self.__await_salesforce_query(body)
        data = self.__get_query_result_as_df(job_id)
        self.logger.info(
            '''Finished querying SF - {0} {1} were found in SF'''.format(str(len(data)), object_name))
        return data

    # Creation, Tracking and Handling results for a generic job
    # operation = insert, upsert, update
    # update requires SF ID ext id only allowed for upserts
    def handle_generic_jobs(self, sf_object: str, data: DataFrame, job_description: str, result_destination='',
                            operation='update',
                            external_id_field_name=None,
                            chunk_size=4000) -> DataFrame: # When a batch takes longer than 5 minutes SF starts retrying... Accounts take 1min/1k
        """
        Creation, Tracking and Handling results for a generic job
        :param sf_object: Salesforce object api name
        :param data:
                    Dataframe with only those columns which need to be inserted/upserted/updated
                    for upsert external_id column is required, for update Id column is required
        :param job_description:
                    Description used by logger
        :param result_destination:
                    Deprecated parameter, which was used to store a csv copy of the result
        :param operation: insert, upsert, update
                          for upsert external_id column is required, for update Id columns is required
        :param external_id_field_name:
                default value: None - Only required for upserts - Needs to be marked as external ID in Salesforce!
        :param chunk_size:
                batchsize for each iteration
        :return: pandas.DataFrame
        e.g.:
                sf.handle_generic_jobs('connectionpoint__c', connection_points_df, 'dw_to_sf_connection_point_sync',
                                        operation='upsert',
                                        external_id_field_name='Unique_Key__c')
        """
        allow_retry = False if operation == 'insert' else True
        pd_list = []
        num_failed = 0
        num_success = 0
        processed = 0
        self.logger.info('{0} - Start for {1} {2}'.format(job_description, str(len(data)), sf_object + 's'))
        for chunk in chunker(data, chunk_size):
            self.logger.info('{0} - Handling chunk of {1} {2}, processed {3} out of {4}'
                             .format(job_description, str(len(chunk)), sf_object + 's', str(processed), str(len(data))))
            job_resource = {'object': sf_object, 'operation': operation,
                            'lineEnding': 'CRLF'}
            if external_id_field_name is not None:  # Full dictionary reset, because the dict format is important...
                job_resource = {'object': sf_object, 'externalIdFieldName': external_id_field_name,
                                'operation': operation,
                                'lineEnding': 'CRLF'}
            result, job_id, api_version = self.__process_sf_job(chunk, job_resource, job_description)
            chunk_result, retry = self.__handle_job_results(result, api_version, job_id, job_description,
                                                            result_destination, allow_retry)
            if allow_retry and retry:
                self.logger.info('{0} - Received locked row error - retrying'
                                 .format(job_description, str(num_failed + num_success), str(num_failed),
                                         str(num_success)))
                # Checking if this eases the locking problem that plagues SF Bulk api V2
                time.sleep(5 * 60)
                result, job_id, api_version = self.__process_sf_job(chunk, job_resource, job_description)
                chunk_result, retry = self.__handle_job_results(result, api_version, job_id, job_description,
                                                                result_destination,
                                                                allow_retry=False)
            num_failed += int(result[0].get('numberRecordsFailed'))
            num_success += int(result[0].get('numberRecordsProcessed')) - int(result[0].get('numberRecordsFailed'))
            pd_list.append(chunk_result)
            processed += len(chunk)
        self.logger.info('{0} - Finished, total processed: {1}, number failed: {2}, number success: {3}'
                         .format(job_description, str(num_failed + num_success), str(num_failed), str(num_success)))
        return pd.concat(pd_list)

    def map_external_reference_to_salesforce_id(self, ext_ref_ids_list: list, sf_object_name: str, ext_ref_name: str,
                                                ext_ref_is_string=True) -> DataFrame:
        """
        maps external references values to their salesforce ID value
        :param ext_ref_ids_list:
            list of ids recognized by Salesforce as Extenral ID
        :param sf_object_name:
            Salesforce object api name
        :param ext_ref_name:
            column name of the ext_ref_ids
        :param ext_ref_is_string:
            indication if the ext_ref is of type str - SF queries expect different quotes for numeric values
        :return: pandas.DataFrame with columns: [Id, Ext_ref]
        """
        pd_list = []
        for chunk in chunker(ext_ref_ids_list, 2000):
            attr_quotes = "\'" if ext_ref_is_string else ''
            query = "SELECT Id, {0} from {1} where {0} IN ({2})" \
                .format(ext_ref_name, sf_object_name,
                        ', '.join(attr_quotes + str(lynx_id) + attr_quotes for lynx_id in chunk))
            body = json.dumps({
                "operation": "query",
                "query": query
            })

            result, job_id = self.__await_salesforce_query(body)
            query_result = self.__get_query_result_as_df(job_id)
            if len(query_result) > 0:
                pd_list.append(query_result)
        return pd.concat(pd_list) if len(pd_list) > 0 else []

    # SalesforcePy - light sf package to create and handle jobs / had to fix some bugs to get it working properly
    def __get_salesforce_client(self):
        self.logger.info('SalesforcePy - initializing client')
        salesforcepy = sfdc.client(
            username=self.username,
            password=self.password,
            client_id=self.client_id,
            client_secret=self.client_secret,
            login_url=self.base_url.replace('https://', ''),
        )
        login_results = salesforcepy.login()
        if len(login_results[1].exceptions) == 0:
            return salesforcepy
        else:
            raise ValueError('Could not sign in to Salesforce: ' + str(login_results[1].exceptions))

    # ~~~~~~~~~~~~~~~~~~~~~~~~~ Utility methods ~~~~~~~~~~~~~~~~~~~~~~~~~

    def get_between_clause(self, start_date, end_date=None, where=False, prefix=None):
        value = 'where' if where else 'and'
        url = f"""+{value}+{self.get_base_between_clause(start_date, end_date, prefix)}"""
        return url

    def get_base_between_clause(self, start_date, end_date=None, prefix=None):
        url = f"""+%28%28{prefix + '.' if prefix is not None else ''}LastModifiedDate%3E{quote_plus(start_date.isoformat())}"""
        if end_date is not None:
            url = url + f"""+and+{prefix + '.' if prefix is not None else ''}LastModifiedDate%3C%3D{quote_plus(end_date.isoformat())}"""

        url = url + f"%29+or+%28{prefix + '.' if prefix is not None else ''}CreatedDate%3E{quote_plus(start_date.isoformat())}"""
        if end_date is not None:
            url = url + f"""+and+{prefix + '.' if prefix is not None else ''}CreatedDate%3C%3D{quote_plus(end_date.isoformat())}"""

        url = url + "%29%29"
        return url

    # ~~~~~~~~~~~~~~~~~~~~~~~~~ Handle jobs methods ~~~~~~~~~~~~~~~~~~~~~~~~~

    # Transform df to csv, upload csv and wait for the result
    def __process_sf_job(self, data, resource, job_description):
        data = data.to_csv(quoting=csv.QUOTE_ALL, index=False, line_terminator='\r\n', encoding='utf-8')
        result = self.salesforcepy.jobs.ingest.create(job_resource=resource)
        self.__validate_job_creation(result, job_description)
        job_id = result[0].get('id')
        result = self.salesforcepy.jobs.ingest.batches(job_id=job_id, csv_file=data)
        self.__validate_job_csv_upload(result, job_description)
        wait_time = self.__get_wait_time()
        result = self.salesforcepy.jobs.ingest.update(job_id=job_id, state='UploadComplete')
        self.__validate_set_job_upload_complete(result, job_description)
        total_time = wait_time
        time.sleep(wait_time)
        result = self.salesforcepy.jobs.ingest.get(job_id=job_id)
        self.logger.info('Awaiting job results - checking every {0} seconds, will timeout after {1} seconds'
                         .format(self.__get_wait_time(), self.__get_timeout()))
        while total_time < self.__get_timeout() and (
                result[0].get('state') == 'UploadComplete' or result[0].get('state') == 'InProgress'):
            time.sleep(wait_time)
            total_time += wait_time
            result = self.salesforcepy.jobs.ingest.get(job_id=job_id)
        self.__validate_job_result(total_time, self.__get_timeout(), result[0].get('state'), str(result[0]))
        self.logger.info('{0} - Finished with current chunk of size: {1}'.format(job_description, str(result[0])))
        return result, job_id, str(result[0].get('apiVersion'))

    # Check for issues with the (query) job result
    @staticmethod
    def __validate_job_result(total_time, timeout_time, state, result_string):
        if total_time >= timeout_time and state != 'JobComplete':
            raise ValueError('Could not process Salesforce query job due to timeout after {0} milliseconds: {1}'
                             .format(str(total_time), result_string))
        if state == 'Failed':
            ValueError('Job processing failed: {0}'.format(result_string))

    # Handle the sf job results
    def __handle_job_results(self, result, api_version, job_id, job_description, destination, allow_retry):
        if int(result[0].get('numberRecordsFailed')) > 0:
            failed_results_csv_path = '{0}/{1}_failed_results_{2}' \
                .format(destination, job_description, get_today_as_string())
            chunk, retry = self.__do_handle_job_results(api_version, job_description, job_id, failed_results_csv_path,
                                                        should_save=False)  # handle failed
            if allow_retry and retry:  # only failed results can return retry = True
                return chunk, retry
        success_results_csv_path = '{0}/{1}_success_results_{2}' \
            .format(destination, job_description, get_today_as_string())
        chunk, retry = self.__do_handle_job_results(api_version, job_description, job_id, success_results_csv_path,
                                                    result_type='successfulresults',
                                                    should_save=False)  # handle success
        return chunk, retry  # success results will always return retry = False

    # Handle the sf job results for failed or success jobs
    def __do_handle_job_results(self, api_version, job_description, job_id, results_csv_path,
                                result_type='failedResults',
                                should_save=False):
        url = 'services/data/v{0}/jobs/ingest/{1}/{2}'.format(api_version, job_id, result_type)
        response = self.call_plain_text_response('GET', url)
        if response.status_code != 204 and len(response.content) > 3:  # No content
            df = pd.read_csv(io.StringIO(response.content.decode('utf-8')), sep=',', dtype=str)
            if 'UNABLE_TO_LOCK_ROW' in response.content.decode('utf-8'):
                return None, True
            else:
                return df, False
        return None, False  # No content

    # Create the job for a query, await results, get results
    def __await_salesforce_query(self, body):
        response = self.call_plain_text_response('POST', self.query_job_url, data=body)
        job_id = json.loads(response.content).get('id')
        wait_time = self.__get_wait_time()
        url = self.query_job_url + '/' + job_id
        result = json.loads(
            self.call_plain_text_response('GET', url).content)
        total_time = wait_time
        time.sleep(self.__get_wait_time())
        self.logger.info('Awaiting query results - checking every {0} seconds, will timeout after {1} seconds'
                         .format(self.__get_wait_time(), self.__get_timeout()))
        while total_time < self.__get_timeout() and (
                result.get('state') == 'UploadComplete' or result.get('state') == 'InProgress'):
            time.sleep(self.__get_wait_time())
            total_time += wait_time
            result = json.loads(
                self.call_plain_text_response('GET', url).content)
        self.__validate_job_result(total_time, self.__get_timeout(), result.get('state'), str(result))
        return result, job_id

    # Get the result of a query job as a df
    def __get_query_result_as_df(self, job_id, chunk_size=10000):
        url = self.query_job_url + '/' + job_id + '/results?maxRecords=' + str(chunk_size)
        result = self.call_plain_text_response_accept_csv('GET', url)
        if result.status_code != 204:
            df = pd.read_csv(io.StringIO(result.content.decode('utf-8')), dtype=str, sep=',')
            while str(result.headers.get('Sforce-Locator')) != 'null':
                url = self.query_job_url + '/' + job_id + '/results?locator=' + result.headers.get('Sforce-Locator') \
                      + '&maxRecords=10000' + str(chunk_size)
                result = self.call_plain_text_response_accept_csv('GET', url)
                df = df.append(pd.read_csv(io.StringIO(result.content.decode('utf-8')), dtype=str, sep=','))
            return df
        else:
            raise ValueError("Could not retrieve query result: " + str(result.reason))

    # ~~~~~~~~~~~~~~~~~~~~~~~~~ Validation methods ~~~~~~~~~~~~~~~~~~~~~~~~~

    # Check for fatal issues with job creation
    @staticmethod
    def __validate_job_creation(result, job_description):
        if len(result[1].exceptions) > 0:
            raise ValueError(
                '{0} - Could not create Salesforce job: {1}'.format(job_description, str(result[1].exceptions)))

    # Check for fatal issues while uploading the csv for a job
    @staticmethod
    def __validate_job_csv_upload(result, job_description):
        if result[1].status != 201:  # there's a JSON parse exception in SalesforcePy even if result was OK
            raise ValueError('{0} - Could not upload csv: {1}'.format(job_description, str(result[1].exceptions)))

    # Check for fatal issues with updating the job state to upload complete
    @staticmethod
    def __validate_set_job_upload_complete(result, job_description):
        if len(result[1].exceptions) > 0:
            raise ValueError('{0} - Could not update job state: {1}'.format(job_description, str(result[1].exceptions)))

    # ~~~~~~~~~~~~~~~~~~~~~~~~~ Airflow Variables ~~~~~~~~~~~~~~~~~~~~~~~~~
    @staticmethod
    def __get_wait_time():
        return 20

    @staticmethod
    def __get_timeout():
        return 7200

    # --------------------- base methods ---------------------

    def __get_token(self):
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        body = f'''grant_type=password&client_id={self.client_id}&client_secret={self.client_secret}&username={self.username_encoded}&password={self.password}'''
        return json.loads(requests.post(self.base_url + self.auth_url, data=body, headers=headers).text)['access_token']

    def call_plain_text_response(self, method: str, url: str, data: dict = None):
        headers = {
            "Content-Type": "application/json",
            "Authorization": "Bearer {0}".format(self.bearer_token)
        }
        if method == 'GET':
            return requests.get(self.base_url + url, headers=headers)
        elif method == 'POST':
            return requests.post(self.base_url + url, data=data, headers=headers)
        elif method == 'PUT':
            return requests.put(self.base_url + url, data=data, headers=headers)
        elif method == 'PATCH':
            return requests.patch(self.base_url + url, data=data, headers=headers)
        else:
            raise ValueError(f'''Invalid method; accepted values: [GET, POST, PUT, PATCH]''')

    def call_plain_text_response_accept_csv(self, method: str, url: str, data: dict = None):
        headers = {
            "Content-Type": "application/json",
            "Authorization": "Bearer {0}".format(self.bearer_token),
            "Accept": "text/csv"
        }
        if method == 'GET':
            return requests.get(self.base_url + url, headers=headers)
        elif method == 'POST':
            return requests.post(self.base_url + url, data=data, headers=headers)
        elif method == 'PUT':
            return requests.put(self.base_url + url, data=data, headers=headers)
        elif method == 'PATCH':
            return requests.patch(self.base_url + url, data=data, headers=headers)
        else:
            raise ValueError(f'''Invalid method; accepted values: [GET, POST, PUT, PATCH]''')


if __name__ == '__main__':
    client = SalesforceClient()
    result = client.query_sf_data('ACCOUNT', ['Id', 'PersonContactId', 'civat__Legal_Form__c', 'Is_Person_Account__c',
                                              'Customer_Group__c'],
                                  " where Is_Person_Account__c = true and Customer_User_Is_Active__pc = true")
    print(client.bearer_token)
