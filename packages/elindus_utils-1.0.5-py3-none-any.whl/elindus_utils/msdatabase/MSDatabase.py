import logging
import time
import urllib
from abc import ABC

import pandas
import pandas as pd
from pandas import DataFrame
from pandas.api.types import is_datetime64_any_dtype as is_datetime_with_tz
from sqlalchemy import create_engine, text
from sqlalchemy.pool import NullPool
from sqlalchemy.sql.elements import TextClause


class MSDatabase(ABC):
    __db_engine = None

    def __init__(self, host=None, database=None, username=None, password=None, port=1433, odbc_driver_version=18,
                 connection_string=None):
        self.logger = logging.getLogger("MSDatabase")
        if connection_string is None:
            if (host is None) | (database is None) | (username is None) | (password is None):
                raise Exception(
                    "Cannot create database connection. One of the following parameters is missing: [host, database, username, password, connection_string]")
            host = urllib.parse.quote_plus(host)
            database = urllib.parse.quote_plus(database)
            username = urllib.parse.quote_plus(username)
            password = urllib.parse.quote_plus(password)
            self.connection_string = f'mssql+pyodbc://{username}:{password}@{host}:{port}/{database}?driver=ODBC+Driver+{odbc_driver_version}+for+SQL+Server'
        else:
            self.connection_string = connection_string

    def get_engine(self, nullpool=False):
        if (self.__db_engine is None) & nullpool:
            self.__db_engine = create_engine(self.connection_string, fast_executemany=True,
                                             poolclass=NullPool)
        if (self.__db_engine is None) & (not nullpool):
            self.__db_engine = create_engine(self.connection_string, fast_executemany=True,
                                             poolclass=None, pool_size=2)
        return self.__db_engine

    def select_first(self, sql: TextClause, engine=None):
        """
        choose select_first() over the alternative get_first method.
        we do not want to enforce switching methods just yet.
        :param sql
            Using a TextClause with bindparameters provides safety against sql injection
            implementation is as simple as:
                from sqlalchemy import text
                def my_sql_method(serial_id: str):
                    sql = text('''Select COLUMNS from TABLE where SERIAL_ID = :serial_id''').bindparams(serial_id=serial_id)
                    result = select_first(sql)
        :param engine: Custom engine instance
        :raises TypeError - when sql not an instance  of TextClause
        """
        if not isinstance(sql, TextClause):
            raise TypeError("Use sqlalchemy text and bindparameters")
        return self.get_first(sql, engine)

    def get_first(self, sql, engine=None):
        """
        avoid using get_first and use select_first() instead
        we do not want to enforce switching methods just yet.
        """
        if engine is None:
            engine = self.get_engine()

        def func():
            with engine.connect() as dw_connection:
                result = dw_connection.execute(text(sql) if isinstance(sql, str) else sql)
                return result.fetchone()

        return self.retry(func)

    def execute_sql_clause(self, sql: TextClause, engine=None):
        """
        choose execute_sql_clause() over the alternative execute_sql method.
        we do not want to enforce switching methods just yet.
        :param sql
            Using a TextClause with bindparameters provides safety against sql injection
            implementation is as simple as:
                from sqlalchemy import text
                def my_sql_method(serial_id: str, update_value:col_type):
                    sql = text('''UPDATE TABLE
                            SET COLUMN = :update_value
                            WHERE ID = :serial_id''') \
            .bindparams(serial_id=serial_id, update_value=update_value)
            result = execute_sql_clause(sql)
        :param engine: Custom engine instance
        :raises TypeError - when sql not an instance  of TextClause
        """
        if not isinstance(sql, TextClause):
            raise TypeError("Use sqlalchemy text and bindparameters")
        return self.execute_sql(sql, engine)

    def execute_sql(self, sql, engine=None):
        """
        avoid using execute_sql and use execute_sql_clause instead
        we do not want to enforce switching methods just yet.
        """
        if engine is None:
            engine = self.get_engine()

        def func():
            with engine.connect() as dw_connection:
                return dw_connection.execute(sql)

        return self.retry(func)

    def execute_sql_clause_to_df(self, sql: TextClause, columns=None, engine=None) -> DataFrame:
        """
        choose execute_sql_clause_to_df() over the alternative execute_sql_to_df method.
        we do not want to enforce switching methods just yet.
        :param sql
            Using a TextClause with bindparameters provides safety against sql injection
            implementation is as simple as:
                from sqlalchemy import text
                def my_sql_method(serial_id: str, update_value:col_type):
                    sql = text('''UPDATE TABLE
                            SET COLUMN = :update_value
                            WHERE ID = :serial_id''') \
            .bindparams(serial_id=serial_id, update_value=update_value)
            result = execute_sql_clause(sql)
        :param engine: Custom engine instance
        :param columns: Column labels to use for resulting frame when data does not have them
        :raises TypeError - when sql not an instance  of TextClause
        """
        if not isinstance(sql, TextClause):
            raise TypeError("Use sqlalchemy text and bindparameters")
        return self.execute_sql_to_df(sql=sql, columns=columns, engine=engine)

    def execute_sql_to_df(self, sql, columns, params=None, engine=None):
        """
        avoid using execute_sql_to_df and use method: execute_sql_clause_to_df() instead
        we do not want to enforce switching methods just yet.
        """
        if engine is None:
            engine = self.get_engine()

        def func():
            with engine.connect() as dw_connection:
                if params is None:
                    result = dw_connection.execute(sql)
                else:
                    result = dw_connection.execute(sql, params)
                return pandas.DataFrame([list(x) for x in result], columns=columns)

        return self.retry(func)

    def get_pandas_df_by_clause(self, sql: TextClause, engine=None, parse_dates=None) -> DataFrame:
        """
        choose execute_sql_clause_to_df() over the alternative get_pandas_df method.
        we do not want to enforce switching methods just yet.
        :param sql
            Using a TextClause with bindparameters provides safety against sql injection
            implementation is as simple as:
                from sqlalchemy import text
                def my_sql_method(serial_id: str, update_value:col_type):
                    sql = text('''UPDATE TABLE
                            SET COLUMN = :update_value
                            WHERE ID = :serial_id''') \
            .bindparams(serial_id=serial_id, update_value=update_value)
            result = execute_sql_clause(sql)
        :param engine: Custom engine instance
        :param parse_dates: List of column names to parse as dates.
        :raises TypeError - when sql not an instance  of TextClause
        """
        if not isinstance(sql, TextClause):
            raise TypeError("Use sqlalchemy text and bindparameters")
        return self.get_pandas_df(sql, engine, parse_dates)

    def get_pandas_df(self, sql, params=None, engine=None, parse_dates=None):
        """
        avoid using get_pandas_df and use method: get_pandas_df_by_clause() instead
        we do not want to enforce switching methods just yet.
        """
        if engine is None:
            engine = self.get_engine()

        def func():
            if params is None:
                return pd.read_sql_query(sql, engine, parse_dates=parse_dates)
            else:
                return pd.read_sql_query(sql, params, engine, parse_dates=parse_dates)

        return self.retry(func)

    def to_sql(self, df, table, chuncksize=200, if_exists='append', index=False, schema=None):
        """Performance measurable dataframe insert statement
           avoid using to_sql and use bulk_upsert(), bulk_update instead
           we do not want to enforce switching methods just yet.
        """
        # First convert the DateTimeTZDtypes to datetime64 to prevent the SQLAlchemy error for the following error:
        # sqlalchemy.exc.ProgrammingError: (pyodbc.ProgrammingError) ('String data, right truncation: length 66 buffer 54', 'HY000')
        convert_to_proper_datetime(df)

        def func():
            df.to_sql(name=table, schema=schema, con=self.get_engine(), chunksize=chuncksize, if_exists=if_exists,
                      index=index)

        return self.retry(func)

    def bulk_upsert(self, df, table='', key_cols=[], data_cols=[], moddate_col=None, conn=None):
        if conn is None:
            with self.get_engine().connect() as con:
                self._bulk_upsert(con, data_cols, df, key_cols, moddate_col, table)
                con.connection.commit()
        else:
            self._bulk_upsert(conn, data_cols, df, key_cols, moddate_col, table)

    def _bulk_upsert(self, con, data_cols, df, key_cols, moddate_col, table):
        crsr = con.connection.cursor()
        # con.execute(text("TRUNCATE TABLE fast_executemany_test"))
        crsr.fast_executemany = True  # new in pyodbc 4.0.19
        using_expr = ",".join(["? AS " + x for x in (key_cols + data_cols)])
        on_expr = " AND ".join([("[Target]." + x + " = [Source]." + x) for x in key_cols])
        matched_expr = ",".join([("[Target]." + x + "=[Source]." + x) for x in data_cols])
        matched_expr = matched_expr + ", [Target]." + moddate_col + " = CURRENT_TIMESTAMP" if moddate_col is not None else matched_expr
        nonmatched_expr_cols = ",".join([x for x in (key_cols + data_cols)]) + (
            ("," + moddate_col) if moddate_col is not None else "")
        nonmatched_expr_vals = ",".join(["[SOURCE]." + x for x in (key_cols + data_cols)]) + (
            ", CURRENT_TIMESTAMP" if moddate_col is not None else "")
        sql = """
                    MERGE {} AS [Target] 
                    USING (SELECT {}) AS [Source] 
                    ON {} 
                    WHEN MATCHED THEN UPDATE SET {}
                    WHEN NOT MATCHED THEN INSERT ({}) VALUES ({});""".format(table, using_expr, on_expr, matched_expr,
                                                                             nonmatched_expr_cols, nonmatched_expr_vals)
        params = df[(key_cols + data_cols)].values
        params[pd.isna(params)] = None
        crsr.executemany(sql, params.tolist())

    def bulk_update(self, df, table='', key_cols=[], data_cols=[], moddate_col=None, conn=None):
        if conn is None:
            with self.get_engine().connect() as con:
                self._bulk_update(con, data_cols, df, key_cols, moddate_col, table)
                con.connection.commit()
        else:
            self._bulk_update(conn, data_cols, df, key_cols, moddate_col, table)

    def _bulk_update(self, con, data_cols, df, key_cols, moddate_col, table):
        crsr = con.connection.cursor()
        crsr.fast_executemany = True  # new in pyodbc 4.0.19
        using_expr = ",".join(["? AS " + x for x in (key_cols + data_cols)])
        on_expr = " AND ".join([("[Target]." + x + " = [Source]." + x) for x in key_cols])
        matched_expr = ",".join([("[Target]." + x + "=[Source]." + x) for x in data_cols])
        matched_expr = matched_expr + ", [Target]." + moddate_col + " = CURRENT_TIMESTAMP" if moddate_col is not None else matched_expr
        sql = """
                        MERGE {} AS [Target] 
                        USING (SELECT {}) AS [Source] 
                        ON {} 
                        WHEN MATCHED THEN UPDATE SET {};""".format(table, using_expr, on_expr, matched_expr)
        params = df[(key_cols + data_cols)].values
        crsr.executemany(sql, params.tolist())

    def bulk_insert(self, df, table='', key_cols=[], data_cols=[], moddate_col=None, conn=None):
        if conn is None:
            with self.get_engine().connect() as con:
                self._bulk_insert(con, data_cols, df, key_cols, moddate_col, table)
                con.connection.commit()
        else:
            self._bulk_insert(conn, data_cols, df, key_cols, moddate_col, table)

    def _bulk_insert(self, con, data_cols, df, key_cols, moddate_col, table):
        crsr = con.connection.cursor()
        crsr.fast_executemany = True  # new in pyodbc 4.0.19
        using_expr = ",".join(["? AS " + x for x in (key_cols + data_cols)])
        on_expr = " AND ".join([("[Target]." + x + " = [Source]." + x) for x in key_cols])
        nonmatched_expr_cols = ",".join([x for x in (key_cols + data_cols)]) + (
            ("," + moddate_col) if moddate_col is not None else "")
        nonmatched_expr_vals = ",".join(["[SOURCE]." + x for x in (key_cols + data_cols)]) + (
            ", CURRENT_TIMESTAMP" if moddate_col is not None else "")
        sql = """
                            MERGE {} AS [Target] 
                            USING (SELECT {}) AS [Source] 
                            ON {}
                            WHEN NOT MATCHED THEN INSERT ({}) VALUES ({});""".format(table, using_expr, on_expr,
                                                                                     nonmatched_expr_cols,
                                                                                     nonmatched_expr_vals)
        params = df[(key_cols + data_cols)].values
        params[pd.isna(params)] = None
        crsr.executemany(sql, params.tolist())

    def retry(self, method, times=3, sleep=5):
        counter = 1
        while counter <= times:
            try:
                return method()
            except Exception as e:
                if counter >= times:
                    raise e
                else:
                    time.sleep(sleep)
            counter = counter + 1


def convert_to_proper_datetime(df):
    if len(df) > 0:
        for column in df.columns:
            if is_datetime_with_tz(df[column]):
                df[column] = df[column].apply(lambda d: d.replace(tzinfo=None))
                df[column] = df[column].astype('datetime64[ns]')
