import json
from typing import Union

import requests
from requests import Response

from elindus_utils.utils.utilspy import validate_required_attribute


class LynxClient():

    def __init__(self, base_url: str, api_key: str = None, headers: dict = None):
        super().__init__()
        if headers is not None:
            self.headers = headers
        else:
            validate_required_attribute(api_key, 'API_KEY', custom_error='Either headers or api_key is required')
            self.headers = {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'X-API-KEY': api_key
            }
        self.base_url = validate_required_attribute(base_url, 'base_url')

    def __check_for_and_raise_error(self, response, raise_errors):
        if raise_errors and (len(response.get('errorMessage')) > 0):
            raise ValueError(response.get('errorMessage'))
        else:
            return response

    # raise_errors only possible when parse_json=True
    def call_lynx_get(self, url: str, parse_response=True, raise_errors=False) -> Union[dict, Response]:
        """
        :param url: URL based on https://api-lynx.elindus.be/swagger/
                    e.g. : api/Project/Create
        :param parse_response: mark True if Response object dict needs to be parsed
        :param raise_errors:
            if parse_response=True and raise_errors=True,
            method will return ValueError with errror value when API call returns 'errorMessage' in response
        :return: :class:`Response <Response>` - if parse_response = False,
                 :dict -  if parse_response = True,
        :rtype: requests.Response | dict
        """
        response = requests.get(self.base_url + url, headers=self.headers)
        if parse_response:
            return self.__check_for_and_raise_error(json.loads(response.text), raise_errors)
        else:
            return response

    def call_lynx_post(self, url: str, json_body: dict, parse_response=True, raise_errors=False) -> Union[dict, Response]:
        """
        Lynx client method for POST calls
        :param url: URL based on https://api-lynx.elindus.be/swagger/
                    e.g. : api/Project/Create
        :param json_body: dict with post body
        :param parse_response: mark True if Response object dict needs to be parsed
        :param raise_errors:
            if parse_response=True and raise_errors=True,
            method will return ValueError with errror value when API call returns 'errorMessage' in response
        :return: :class:`Response <Response>` - if parse_response = False,
                 :dict -  if parse_response = True,
        :rtype: requests.Response | dict
        """
        response = requests.post(self.base_url + url, json=json_body, headers=self.headers)
        if parse_response:
            return self.__check_for_and_raise_error(json.loads(response.text), raise_errors)
        else:
            return response
