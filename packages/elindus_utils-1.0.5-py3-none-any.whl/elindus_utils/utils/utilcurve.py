import numpy as np
import pandas as pd
from scipy.optimize import curve_fit


def objective(x, a, b, c, d, e, f, g):
    return (a * x) + (b * x ** 2) + (c * x ** 3) + (d * x ** 4) + (e * x ** 5) + (f * 0) + g


def to_year_fractions(x, days_in_year=365):
    dataframe = pd.DataFrame(x)

    data = dataframe.values
    # choose the input and output variables
    x = np.arange(0, len(dataframe), 1)
    y = data.reshape(len(dataframe), )

    # curve fit
    popt, _ = curve_fit(objective, x, y)
    # summarize the parameter values
    # a, b, c, d, e, f = popt
    a, b, c, d, e, f, g = popt
    # plot input vs output
    # pyplot.scatter(x, y)
    # define a sequence of inputs between the smallest and largest known inputs
    # x_line = np.arange(min(x), max(x), 1)
    # calculate the output for the range
    # y_line = objective(x_line, a, b, c, d, e, f)
    # y_line = objective(x_line, a, b, c, d, e, f, g)
    # create a line plot for the mapping function
    #print(a, b, c, d, e, f, g)
    # pyplot.plot(x_line, y_line, '--', color='red')
    #pyplot.show()

    xvals_year = np.arange(0, 52, 52 / days_in_year)
    yvals_year = [objective(x, a, b, c, d, e, f, g) for x in xvals_year]
    return yvals_year
