from datetime import datetime


def get_today_as_string() -> str:
    return datetime.today().strftime('%d%m%Y')


def chunker(seq, size):
    return [seq[pos:pos + int(size)] for pos in range(0, len(seq), int(size))]


def validate_required_attribute(attribute, name, custom_error=None):
    if attribute is None:
        if custom_error is not None:
            raise ValueError(custom_error)
        else:
            raise ValueError(f'''Attribute {name} is required''')
    return attribute
